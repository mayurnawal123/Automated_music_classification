function [ output ] = selectsec(input)

    %The input is a 30 sec file
    % The output is a 1 sec array who has the highest energy among the 1 sec 
    % sequences from duration 10 to 30 sec.
    %This function is called by the function "SurfFeat" to select the
    %relevant 1 sec file from the input music file.

    [song, Freq]=auread(input);

    energy=0;
    output=0;
    for k=1:10
        seq=song(Freq*(10+k)+1:Freq*(k+11));
    %     plot(seq);
    %     figure;
        energy_temp=sum(seq.*seq);
        if energy_temp>energy
            output=seq;
            energy=energy_temp;
        end
    end

end

