function index = modifiedmahal(Y,Xrock,Xjazz,Xhiphop,Xclassical);

% 
%   index = modifiedmahal returns the index corrosponding to the genre which has minimum Mahalanobis distance (in squared units) of
%    Y from the sample data in X.
%    => if output = 1 => genre is rock 
%    => if output = 2 => genre is jazz 
%    => if output = 3 => genre is hiphop 
%    => if output = 4 => genre is classical 

%     formulae for mahalanobis distance  D2(I) = (Y(I,:)-MU) * SIGMA^(-1) * (Y(I,:)-MU)',
%
%   where MU and SIGMA are the sample mean and covariance of the data in X.
%   Rows of Y and X correspond to observations, and columns to variables.  X
%   and Y must have the same number of columns, but can have different numbers
%   of rows.  X must have more rows than columns.
%
[rxrock,cx] = size(Xrock);
[rxjazz,cx] = size(Xjazz);
[rxhiphop,cx] = size(Xhiphop);
[rxclassical,cx] = size(Xclassical);


[ry,cy] = size(Y);

if cx ~= cy
   error('stats:mahal:InputSizeMismatch',...
         'Requires the inputs to have the same number of columns.');
end

if rxrock < cx
   error('stats:mahal:TooFewRows',...
         'The number of rows of X must exceed the number of columns.');
end
if any(imag(Xrock(:))) | any(imag(Y(:)))
   error('stats:mahal:NoComplex','MAHAL does not accept complex inputs.');
end
% calculating the mean 
mrock = mean(Xrock,1);
mjazz = mean(Xjazz,1);
mhiphop = mean(Xhiphop,1);
mclassical = mean(Xclassical,1); 


Mrock = mrock(ones(ry,1),:);
Mjazz = mjazz(ones(ry,1),:);
Mhiphop = mhiphop(ones(ry,1),:);
Mclassical = mclassical(ones(ry,1),:);

Crock = Xrock - mrock(ones(rxrock,1),:);
Cjazz = Xjazz - mjazz(ones(rxjazz,1),:);
Chiphop = Xhiphop - mhiphop(ones(rxhiphop,1),:);
Cclassical = Xclassical - mclassical(ones(rxclassical,1),:);

% q-r decomposition of the reduced mean matrices for every genre. 

[Qrock,Rrock] = qr(Crock,0);
[Qjazz,Rjazz] = qr(Cjazz,0);
[Qhiphop,Rhiphop] = qr(Chiphop,0);
[Qclassical,Rclassical] = qr(Cclassical,0);

rirock = Rrock'\(Y-Mrock)';
rijazz = Rjazz'\(Y-Mjazz)';
rihiphop = Rhiphop'\(Y-Mhiphop)';
riclassical = Rclassical'\(Y-Mclassical)';

% calculating the final distance between the input and training
% observation matrises 
drock = sum(rirock.*rirock,1)'*(rxrock-1);
djazz = sum(rijazz.*rijazz,1)'*(rxjazz-1);
dhiphop = sum(rihiphop.*rihiphop,1)'*(rxhiphop-1);
dclassical = sum(riclassical.*riclassical,1)'*(rxclassical-1);

D = [drock djazz dhiphop dclassical];
[d index] = min(D);



