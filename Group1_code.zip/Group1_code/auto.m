function out=auto(in,n)
%finds autocorrelation of sequence in till index n

    out=zeros(1,n+1);
    len=length(in);
    for i=0:n
        out(i+1)=sum((in(1:len-i).*in(1+i:end)));
    end    

end