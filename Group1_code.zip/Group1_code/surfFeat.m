function [cent roll flux zeroC Lenergy] = surfFeat(input)

% This code will extract the surface feautres of the input wave.
% The input is the name of the file which (30 sec long) has to be
% featurized.
% 
% The input wave is then divided into 40 non-overlapping sequences of 20ms 
% length each. FFT is then computed for the thing.
% 
% The outputs are as follows:
% 1) cent is a length 2 vector consisting of the mean and std centroid of the 
% 40 sequences.
% 
% 2) roll and flux also have mean and std
% 
% 3) zeroC has the avg number of zero crossings
% 
% 4) Lenergy has the no. of sequences having lower energy than the avg energy.

input=selectsec(input);         %Finding the 1 sec file from the 30 sec input

Seqs=40;
fftMultiplier=1;

centroids = zeros(1,Seqs);          %stores the centroids for each sequence
rolloffs=zeros(1,Seqs);             
fluxes=zeros(1,Seqs-1);
zerocrosses=zeros(1,Seqs);

sampleFreq=length(input);       

winLen=floor(sampleFreq*20/1000);
fftLen=winLen*fftMultiplier;

sequences=zeros(Seqs,winLen);           %stores the ith 20ms sequence in the ith row
energy=zeros(1,Seqs);                   %stores the energy of each sequence
ffts=zeros(Seqs,floor(fftLen/2));       %stores the ith 20ms sequence fft in the ith row

for i=1:Seqs
    %This loop extracts each 20ms sequence from the input sequence and
    %computes its fft.
    sequences(i,:)=input(1+(i-1)*winLen:i*winLen);
    x=fft(sequences(i,:),fftLen);
    
    ffts(i,:)=abs(x(1:floor(fftLen/2)));
    energy(i)=sqrt(sum((ffts(i,:).*ffts(i,:))));
    ffts(i,:)=100*ffts(i,:)/energy(i);
    
%     figure();
%     plot(log(ffts(i,:)));
%     title(i);
end

fftLen=floor(winLen*fftMultiplier/2);

for i=1:Seqs
    
    % Calculating the centroid for the ith sequence 
    num=0;
    den=0;
    for j=1:fftLen
        num=num+j*ffts(i,j);
        den=ffts(i,j)+den;
    end
    centroids(i)=((sampleFreq/1000)*(num/den))/(fftLen*2);
    
    % Calculating the rolloff for the ith sequence
    total=sum(ffts(i,:));
    sumtillnow=zeros(1,fftLen);
    sumtillnow(1)=ffts(i,1);
    for j=2:fftLen
        sumtillnow(j)=sumtillnow(j-1)+ffts(i,j);
    end
    sumtillnow=abs(sumtillnow-0.85*total);
    index=find(sumtillnow==min(sumtillnow));
    rolloffs(i)=(index(1)*(sampleFreq/1000))/(fftLen*2);
    
    %Calculating fluxes for the ith sequence (except for the first)
    if(i~=1)
        diff=ffts(i,:)-ffts(i-1,:);
        diff=diff.*diff;
        fluxes(i-1)=sqrt(sum(diff));
    end
    
    %Calculating zero crossings for the ith sequence 
    zerocrosses(i)=zerocrossing(sequences(i,:));
    
end

% figure;
% plot(centroids);
% title('centroids');
% figure;
% plot(rolloffs);
% title('rolloffs');
% figure;
% plot(fluxes);
% title('fluxex');
% figure;
% plot(zerocrosses);
% title('zeros');


%Percentage of low energy sequences
avgener=mean(energy);
energy=energy-avgener;
Lenergy=length(find(energy<0));


cent(1)=mean(centroids);
cent(2)=std(centroids);
roll(1)=mean(rolloffs);
roll(2)=std(rolloffs);
flux(1)=mean(fluxes);
flux(2)=std(fluxes);
zeroC(1)=mean(zerocrosses);
zeroC(2)=std(zerocrosses);

end

    
    
    
    
    
    
    
    








