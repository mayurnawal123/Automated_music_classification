function  [amp,peaks]=rhythm( filename,bw,N,dec_order )
%filename:filename of the music(.au) file 
%bw:bandwwidth of the first stage lowpass filter
%N:order of filter to be used
%dec_order:number of stages


in=auread(filename);
in_sig=in(:,1);
close all;
b=bw;   %bandwidth
l=0.99; %single pole low pass filter
autocor=0;
hist=zeros(1,300);
for j=1:65536+4096:length(in_sig)-65536;
    in=in_sig(j:j+65536);   %windowed signal
    out=0;
    for i=1:dec_order;  %operations for each component
        high=filter(fir1(N,[b,l]),1,in);    %calculating the high pass component
        low=filter(fir1(N,b),1,in);     %calculating the low pass component
        b=b/2;      %for next stage
        l=l/2;
        in=low;
        y=high;
        y=abs(y);   %full wave rectification
        y=filter(0.01,[1,-0.99],y); %low pass filtering
        y=y(1:16:length(y));    %downsampling
        y=y-mean(y);    %normalisation
        out=out+y;

    end
    ac=auto(out,length(out));
    ac=smooth(ac,75);   % smooth autocorrelation so that unwanted peaks are removed
    [xmax,imax,xmin,imin] = extrema(ac);    %calculate all peaks of autocorrelation according to their amplitudes
    if(length(imax)>10)
        a=10;
    else
        a=length(imax);
    end
    for m=2:a;
        temp=22050*60/(imax(m)*16); %representaion in terms of beats per minute
        if( temp<300)
            if(xmax(m)>=0)
                [min_l,min_r]=neigh_min(imax(m),imin);
                minimum=(xmin(min_l)+xmin(min_r))/2;    %to calculate average difference
                hist(ceil(temp))=hist(ceil(temp))+xmax(m)-minimum;  % update histogram values
            end
        end
    end
end
[xmax,imax,xmin,imin] = extrema(hist);  %calculate peaks of histogram
% plot(hist)

%take 4 most prominent peaks 
peaks=imax(1:4);
total=sum(hist);
amp=zeros(1,4);
amp=xmax(1:4)/total;

%arranging peaks in order of the beats per minute value index
index=find(peaks==min(peaks));
temp=peaks(1);
peaks(1)=peaks(index);
peaks(index)=temp;
temp=amp(1);
amp(1)=amp(index);
amp(index)=temp;
for i=2:4;   
    peaks(i)=peaks(i)/peaks(1); %ratio period calculation
end
last=find(peaks==max(peaks(2:end)));
second=find(peaks==min(peaks(2:end)));
temp=peaks(2);
peaks(2)=peaks(second);
peaks(second)=temp;
temp=amp(2);
amp(2)=amp(second);
amp(second)=temp;
temp=peaks(4);
peaks(4)=peaks(last);
peaks(last)=temp;
temp=amp(4);
amp(4)=amp(last);
amp(last)=temp;

end

