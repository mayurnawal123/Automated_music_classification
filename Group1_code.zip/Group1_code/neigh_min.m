function [min_l,min_r] = neigh_min( maximum,a )
%find the indeces of nearest minimas on both sides of the maximum 
a=a-maximum;
ind= find(a<0);
min_l=find(a==max(a(ind)));
ind= find(a>0);
if(length(ind)>0)
    min_r=find(a==min(a(ind)));
else
    min_r=min_l;
end

end

