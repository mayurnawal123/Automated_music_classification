function crossings=zerocrossing(input)
%Finds the number of zerocrossings in the given array input.
%This function is called by the "SurfFeat" program.

    input=sign(input);
    input=sign(input+eps);
    output=input;
    for i=2:length(input)
        output(i)=input(i)*input(i-1);
    end
    crossings=length(find(output<0));
end
