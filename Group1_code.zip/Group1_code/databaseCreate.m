function output=databaseCreate
%This function will generate an output file.
%That file will have a struct variable containg the features of the music
%files.
%This function acts on the current open directory and expects only 'au'
%files in that directory. (A very small modification will enable it to work on wav files also.)

list=dir;

output=struct('genre',{},'meanCent',{},'meanRoll',{},'meanFlux',{},'meanZero',{},'stdCent',{},'stdRoll',{},'stdFlux',{},'stdZero',{},'Lenergy',{},'period0',{},'amplitude0',{},'period1',{},'amplitude1',{},'period2',{},'amplitude2',{},'period3',{},'amplitude3',{});

for i =3:length(list)
    filename = list(i).name;
    
    [cent roll flux zeroC Lenergy] = surfFeat(filename);
    [amp,peaks]=rhythm( filename,0.5,50,4 );
    disp(i-2);
    
    output(i-2).genre=1;
    output(i-2).meanCent=cent(1);
    output(i-2).stdCent=cent(2);
    output(i-2).meanRoll=roll(1);
    output(i-2).stdRoll=roll(2);
    output(i-2).meanFlux=flux(1);
    output(i-2).stdFlux=flux(2);
    output(i-2).meanZero=zeroC(1);
    output(i-2).stdZero=zeroC(2);    
    output(i-2).Lenergy=Lenergy;
    
    output(i-2).period0=peaks(1);
    output(i-2).amplitude0=amp(1);
    output(i-2).period1=peaks(2);
    output(i-2).amplitude1=amp(2);
    output(i-2).period2=peaks(3);
    output(i-2).amplitude2=amp(3);
    output(i-2).period3=peaks(4);
    output(i-2).amplitude3=amp(4);
    
end
save('data.mat','output');
end